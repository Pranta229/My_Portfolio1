import Entity.Package;
import EntityList.PackageList;
import GUI.LoginPage;


public class Start {
    public static void main(String[] args) {
		
        LoginPage page = new LoginPage();
		
    }
}
