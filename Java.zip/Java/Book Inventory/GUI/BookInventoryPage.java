package GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Entity.Book;
import EntityList.*;
import Files.FileIO;
public class BookInventoryPage extends JFrame implements ActionListener{
	Font titleFont = new Font("cambria",Font.BOLD,30);
	Font font15 = new Font("cambria",Font.BOLD,15);
	Font font20 = new Font("cambria",Font.BOLD,20);
	
	JTextField idTextField,nameTextField,authorTextField,typeTextField,copyTextField;
	JTextField searchTextField,deleteTextField;
	JTextArea display;
	
	JComboBox typeComboBox;

	JButton addButton,updateButton,searchButton,deleteButton,clearButton,showAllButton;
	JButton logoutButton;
	
	BookList bookList = new BookList(100);
	public JFrame previousPage;
	
	
	public BookInventoryPage(){
		super("Book Management GUI");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(940,650); //width, height
		this.setLocation(150,0); //X, Y
		this.getContentPane().setBackground(new Color(218,232,252));
		this.setLayout(null);

		//===========Load Data From File=================
		FileIO.loadBookFromFile(bookList);
		
		//=================Image Example====================

	
		//============= Title ===========
		JLabel title = new JLabel("Library Management System");
		title.setBounds(230,10,500,50); //X,Y,W,H
		title.setFont(titleFont);
		//=========== Sub Title ==========
		JLabel subTitle = new JLabel("BOOK INFORMATIONS");
		subTitle.setBounds(300,60,320,50); //X,Y,W,H
		subTitle.setFont(new Font("Cambria",Font.BOLD,25));
		
		
		//////////////////////////////////////////////////////////////////////////////
		//---------------------- LEFT SIDE COMPONENTS ------------------------------//
		//////////////////////////////////////////////////////////////////////////////
		
		//============Book Entry Form ===========
		int top = 100;
		int gap = 40;
		//============Book ID Entry  ===========
		JLabel idLabel = new JLabel("Book ID");
		idLabel.setBounds(20,top,200,30); //X,Y,W,H
		idLabel.setFont(font15);
		
		idTextField = new JTextField();
		idTextField.setBounds(20,top+=gap,200,30); //X,Y,W,H
		idTextField.setFont(font15);
		
		//============Book Name Entry  ===========
		JLabel nameLabel = new JLabel("Book Name");
		nameLabel.setBounds(20,top+=gap,200,30); //X,Y,W,H
		nameLabel.setFont(font15);
		
		nameTextField = new JTextField();
		nameTextField.setBounds(20,top+=gap,200,30); //X,Y,W,H
		nameTextField.setFont(font15);
		
		//============Book Author Entry  ===========
		JLabel authorLabel = new JLabel("Book Author Name");
		authorLabel.setBounds(20,top+=gap,200,30); //X,Y,W,H
		authorLabel.setFont(font15);
		
		authorTextField = new JTextField();
		authorTextField.setBounds(20,top+=gap,200,30); //X,Y,W,H
		authorTextField.setFont(font15);
		
		//============Book Type Entry  ===========
		JLabel typeLabel = new JLabel("Book Type");
		typeLabel.setBounds(20,top+=gap,200,30); //X,Y,W,H
		typeLabel.setFont(font15);
		
		typeTextField = new JTextField();
		//typeTextField.setBounds(20,top+=gap,200,30); //X,Y,W,H
		//typeTextField.setFont(font15);
		
		typeComboBox = new JComboBox( new String[]{"Daram","Story","Sci-Fi","Programming","Text-Book"});
		typeComboBox.setBounds(20,top+=gap,200,30); //X,Y,W,H
		typeComboBox.setFont(font15);
		this.add(typeComboBox);
		
		//============Book Copy Entry  ===========
		JLabel copyLabel = new JLabel("Book Copy");
		copyLabel.setBounds(20,top+=gap,200,30); //X,Y,W,H
		copyLabel.setFont(font15);
		
		copyTextField = new JTextField();
		copyTextField.setBounds(20,top+=gap,200,30); //X,Y,W,H
		copyTextField.setFont(font15);
		
		//============Book Entry  Buttons===========
		addButton = new JButton("ADD");
		addButton.setBounds(20,top+=gap+20,200,30); //X,Y,W,H
		addButton.setBackground(Color.GREEN);
		addButton.setFont(font15);
		addButton.addActionListener(this);
		
		
		updateButton = new JButton("UPDATE");
		updateButton.setBounds(20,top+=gap,200,30); //X,Y,W,H
		updateButton.setBackground(Color.BLUE);
		updateButton.setForeground(Color.WHITE);
		updateButton.setFont(font15);
		updateButton.addActionListener(this);
		
		
		//============RIGHT SIDE COMPONENTS=========
		top = 100;
		gap = 40;
		//============Book Search Entry  ===========
		JLabel searchLabel = new JLabel("Search By Book ID");
		searchLabel.setBounds(700,top,200,30); //X,Y,W,H
		searchLabel.setFont(font15);
		
		searchTextField = new JTextField();
		searchTextField.setBounds(700,top+=gap,200,30); //X,Y,W,H
		searchTextField.setFont(font15);
		
		searchButton = new JButton("SEARCH");
		searchButton.setBounds(700,top+=gap,200,30); //X,Y,W,H
		searchButton.setBackground(Color.YELLOW);
		searchButton.setFont(font15);
		searchButton.addActionListener(this);
		
		
		//============Book Delete Entry  ===========
		JLabel deleteLabel = new JLabel("Delete By Book ID");
		deleteLabel.setBounds(700,top+=gap,200,30); //X,Y,W,H
		deleteLabel.setFont(font15);
		
		deleteTextField = new JTextField();
		deleteTextField.setBounds(700,top+=gap,200,30); //X,Y,W,H
		deleteTextField.setFont(font15);
		
		deleteButton = new JButton("DELETE");
		deleteButton.setBounds(700,top+=gap,200,30); //X,Y,W,H
		deleteButton.setBackground(Color.RED);
		deleteButton.setForeground(Color.WHITE);
		deleteButton.setFont(font15);
		deleteButton.addActionListener(this);
		
		///////////////// Show All Book information ///////////////
		
		showAllButton = new JButton("SHOW ALL");
		showAllButton.setBounds(700,500,200,30); //X,Y,W,H
		showAllButton.setBackground(Color.PINK);
		showAllButton.setForeground(Color.WHITE);
		showAllButton.setFont(font15);
		showAllButton.addActionListener(this);
		
		///////////////// Clear Screen ///////////////
		
		clearButton = new JButton("CLEAR SCREEN");
		clearButton.setBounds(700,550,200,30); //X,Y,W,H
		clearButton.setBackground(Color.DARK_GRAY);
		clearButton.setForeground(Color.WHITE);
		clearButton.setFont(font15);
		clearButton.addActionListener(this);
		
		
		
		//----------------- Logout Button ------------------
		logoutButton = new JButton("Logout");
		logoutButton.setBounds(700,20,200,30); //X,Y,W,H
		logoutButton.setBackground(Color.RED);
		logoutButton.setForeground(Color.WHITE);
		logoutButton.setFont(font15);
		logoutButton.addActionListener(this);
		this.add(logoutButton);
		
		//Data Display Area 250,100,400,500
		display = new JTextArea();
		display.setFont(font20);
		
		JScrollPane jsp = new JScrollPane(display);
		jsp.setBounds(250,100,400,500);
		this.add(jsp);
		reloadData();
		
		
		//================= ADD ALL THE COMPONENTS TO CONTAINER ======================//
		this.add(title);
		this.add(subTitle);
		this.add(idLabel);
		this.add(idTextField);
		this.add(nameLabel);
		this.add(nameTextField);
		this.add(authorLabel);
		this.add(authorTextField);
		this.add(typeLabel);
		//this.add(typeTextField);
		this.add(copyLabel);
		this.add(copyTextField);
		this.add(addButton);
		this.add(updateButton);
		this.add(searchLabel);
		this.add(searchTextField);
		this.add(searchButton);
		this.add(deleteLabel);
		this.add(deleteTextField);
		this.add(deleteButton);
		this.add(clearButton);
		this.add(showAllButton);
		
		//================= DISPLAY THE FRAME ======================//
		this.setVisible(true);
		
	}
	
	public void actionPerformed(ActionEvent e){
		if(addButton == e.getSource()){
			System.out.println("ADD CLICKED");			
			Book b = bookList.getById(idTextField.getText());
			if(b==null){
				if(!idTextField.getText().isEmpty() &&
				!nameTextField.getText().isEmpty() &&
				!authorTextField.getText().isEmpty() &&
				!copyTextField.getText().isEmpty() ){
					Book tempb = new Book(idTextField.getText(),
									nameTextField.getText(),
									authorTextField.getText(),
									typeComboBox.getSelectedItem().toString(),
									Integer.parseInt(copyTextField.getText()));
					bookList.insert(tempb);
					FileIO.writeBookInFile(tempb);
					reloadData();
				}
				else{
					JOptionPane.showMessageDialog(this,"Provide All Information");
				}
			}
			else{
				JOptionPane.showMessageDialog(this,"Book Id Already Used");
			}
		
		}
		else if(updateButton == e.getSource()){
			System.out.println("UPDATE CLICKED");
			Book b = bookList.getById(idTextField.getText());
			if(b!=null){
				if(!nameTextField.getText().isEmpty()){
					b.setBookName(nameTextField.getText());
				}
				if(!authorTextField.getText().isEmpty()){
					b.setBookAuthor(authorTextField.getText());
				}
				if(!typeTextField.getText().isEmpty()){
					b.setBookType(typeTextField.getText());
				}
				if(!copyTextField.getText().isEmpty()){
					b.setBookCopy(Integer.parseInt(copyTextField.getText()));
				}
				reloadData();
				JOptionPane.showMessageDialog(this,"Book Updated");
			}
			else{
				JOptionPane.showMessageDialog(this,"No Book Found");
			}
		}
		else if(searchButton == e.getSource()){
			System.out.println("SEARCH CLICKED");	
			Book b = bookList.getById(searchTextField.getText());
			if(b!=null){
				display.setText(b.getBookAsString());
			}
			else{
				JOptionPane.showMessageDialog(this,"No Book Found");
			}
		}
		else if(deleteButton == e.getSource()){
			System.out.println("DELETE CLICKED");
			Book b = bookList.getById(deleteTextField.getText());
			if(b!=null){
				bookList.removeById(deleteTextField.getText());
				reloadData();
			}
			else{
				JOptionPane.showMessageDialog(this,"No Book Found");
			}
		}
		else if(showAllButton == e.getSource()){
			System.out.println("SHOW ALL CLICKED");
			reloadData();
		}
		else if(clearButton == e.getSource()){
			System.out.println("CLEAR CLICKED");
		}
		else if(logoutButton == e.getSource()){
			System.out.println("Logout CLICKED");
			previousPage.setVisible(true);
			this.dispose();
		}
	}
	public void reloadData(){
		display.setText(bookList.getAllBookAsString());
	}
}