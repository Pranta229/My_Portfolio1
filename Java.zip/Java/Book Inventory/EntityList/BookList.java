package EntityList;
import Entity.Book;
public class BookList{
	private Book books[];
	public BookList(){
		books = new Book[5];
	}
	public BookList(int size){
		books = new Book[size];
	}
	
	public void insert(Book b){
		boolean flag = false;
		for(int i=0;i<books.length;i++){
			if(books[i]==null){
				books[i] = b;
				flag = true;
				break;
			}
		}
		if(flag){
			System.out.println("Successfully Inserted.");
		}
		else{
			System.out.println("Insertion Failed!");
		}
	}
	public Book getById(String id){
		boolean flag = false;
		Book b = null;
		for(int i=0;i<books.length;i++){
			if(books[i]!=null){
				if(books[i].getBookId().equals(id)){
					b = books[i];
					flag = true;
					break;
				}
			}
		}
		if(flag){
			System.out.println("Book Found.");
		}
		else{
			System.out.println("No Book with This Id!");
		}
		return b;
	}
	
	public void removeById(String id){
		boolean flag = false;
		for(int i=0;i<books.length;i++){
			if(books[i]!=null){
				if( books[i].getBookId().equals(id)){
					books[i] = null;
					flag = true;
					break;
				}
			}
		}
		if(flag){
			System.out.println("Book Removed.");
		}
		else{
			System.out.println("No Book with This Id!");
		}
	}
	public void showAll(){
		for(int i=0;i<books.length;i++){
			if(books[i]!=null){
				System.out.println("--------------");
				books[i].showBookInfo();
				System.out.println("--------------");
			}
		}
	}
	public String getAllBookAsString(){
		String allBook = "";
		for(int i=0;i<books.length;i++){
			if(books[i]!=null){
				allBook += "--------------"+"\n"+
				books[i].getBookAsString()+"\n"+
				"--------------"+"\n";
			}
		}
		return allBook;
	}
}