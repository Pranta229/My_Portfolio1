package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Files.FileIO;
import GUI.PackageManagementPage;

public class LoginPage extends JFrame implements ActionListener {

    // Font styles
    private Font font25 = new Font("Cambria", Font.BOLD, 25);

    // UI Components
    private JLabel userLabel, passLabel, userImage, backgroundLabel;
    private JTextField userTextField;
    private JPasswordField userPassField;
    private JButton loginBtn, registerBtn;

    // Constructor
    public LoginPage() {
        super("Login Page");

        // Frame settings
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400, 400); // width, height
        this.setLocation(200, 100); // x, y
        this.setLayout(null);

        // Set background image
        setBackgroundImage();

        // Adding UI Components
        addComponents();

        // Make the frame visible
        this.setVisible(true);
    }

    // Method to set background image
    private void setBackgroundImage() {
        // Load background image
        ImageIcon backgroundImage = new ImageIcon("./images/background.jpg"); // Replace with your image path
        backgroundLabel = new JLabel(backgroundImage);

        // Set size and layout for background
        backgroundLabel.setBounds(0, 0, this.getWidth(), this.getHeight());

        // Add the background label first, so it will be the backmost component
        this.add(backgroundLabel);
    }

    // Method to add components to the frame
    private void addComponents() {
        // User Image (optional user icon)
        userImage = new JLabel(new ImageIcon("./images/user.png")); // User icon
        userImage.setBounds(190, 0, 50, 50); // x, y, width, height
        backgroundLabel.add(userImage); // Add to background label to keep layering correct

        // User Name Label
        userLabel = new JLabel("User Name");
        userLabel.setBounds(100, 50, 200, 30); // x, y, width, height
        userLabel.setFont(font25);
        backgroundLabel.add(userLabel);

        // User Name TextField (with transparency)
        userTextField = new JTextField();
        userTextField.setBounds(100, 90, 200, 30);
        userTextField.setFont(font25);
        userTextField.setOpaque(false); // Make text field transparent
        userTextField.setBackground(new Color(0, 0, 0, 0)); // Transparent background
        backgroundLabel.add(userTextField);

        // Password Label
        passLabel = new JLabel("Password");
        passLabel.setBounds(100, 130, 200, 30); // x, y, width, height
        passLabel.setFont(font25);
        backgroundLabel.add(passLabel);

        // Password Field (with transparency)
        userPassField = new JPasswordField();
        userPassField.setBounds(100, 170, 200, 30);
        userPassField.setFont(font25);
        userPassField.setOpaque(false); // Make password field transparent
        userPassField.setBackground(new Color(0, 0, 0, 0)); // Transparent background
        userPassField.setEchoChar('*');
        backgroundLabel.add(userPassField);

        // Login Button
        loginBtn = new JButton("Login");
        loginBtn.setBounds(100, 210, 200, 30);
        loginBtn.setFont(font25);
        loginBtn.setBackground(new Color(84, 150, 214)); // Button color
        loginBtn.setForeground(Color.WHITE);
        loginBtn.addActionListener(this);
        backgroundLabel.add(loginBtn);

        // Register Button
        registerBtn = new JButton("Register");
        registerBtn.setBounds(100, 250, 200, 30);
        registerBtn.setFont(font25);
        registerBtn.setBackground(Color.YELLOW);
        registerBtn.setForeground(Color.BLACK);
        registerBtn.addActionListener(this);
        backgroundLabel.add(registerBtn);
    }

    // ActionListener implementation for button clicks
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginBtn) {
            handleLogin();
        } else if (e.getSource() == registerBtn) {
            handleRegister();
        }
    }

    // Handles login logic
    private void handleLogin() {
        // Get username and password
        String userName = userTextField.getText();
        String password = new String(userPassField.getPassword());

        // Validate the user credentials using FileIO class
        if (FileIO.checkUser(userName, password)) {
            JOptionPane.showMessageDialog(this, "Hello " + userName);

            // Open Package Management Page after successful login
            new PackageManagementPage();

            // Optionally reset fields after successful login
            resetFields();
        } else {
            JOptionPane.showMessageDialog(this, "Wrong User Name or Password", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Handles registration logic (currently just showing a message)
    private void handleRegister() {
        JOptionPane.showMessageDialog(this, "Do you want to Register?", "New User", JOptionPane.WARNING_MESSAGE);
    }

    // Resets the input fields after login or failed attempt
    private void resetFields() {
        userTextField.setText("");
        userPassField.setText("");
    }

    // Main method to launch the application
    public static void main(String[] args) {
        new LoginPage(); // Launch login page
    }
}